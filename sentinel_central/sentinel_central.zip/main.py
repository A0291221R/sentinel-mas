import asyncio
import os, logging, sys
# from app.bus import MessageBus
# from app.tracking_service import IDFusion, TargetTrackingSystem
# from app.notification_service import RealtimeAlertNotification
# from app.envelope import pack_event
import uvicorn
import app.webapi_service as webapi

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    stream=sys.stdout,
)


SERVICE_NAME = os.getenv("SERVICE_NAME", "centralized-server")

async def main():
    loop = asyncio.get_event_loop()
    # bus = MessageBus(loop)
    # await bus.connect()

    # Inject bus into API
    # webapi.bus = bus

    # Init workers
    # idf = IDFusion(bus, created_by="idf-service-1")
    # tts = TargetTrackingSystem(bus, created_by="tts-service-1")
    # ran = RealtimeAlertNotification(created_by="ran-svc-1")

    # # Subscriptions
    # await bus.subscribe("par-event", idf.handle_par_event)
    # await bus.subscribe("tts-event", tts.handle_tts_event)
    # await bus.subscribe("movement-update", ran.handle_movement_update)
    # await bus.subscribe("ad-event", ran.handle_ad_event)

    # Run API server
    server = uvicorn.Server(uvicorn.Config(webapi.app, host="0.0.0.0", port=8100))
    await server.serve()

if __name__ == "__main__":
    asyncio.run(main())
